/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        background: '#F0F0F0',
        foreground: '#121212',
        'primary-red': '#D02020',
        'primary-blue': '#1040C0',
        'primary-yellow': '#F0C020',
        'muted-gray': '#E0E0E0',
        'pale-yellow': '#FFF9C4',
      },
      fontFamily: {
        sans: ['Outfit', 'Noto Sans Devanagari', 'Noto Sans Gujarati', 'sans-serif'],
      },
      boxShadow: {
        'hard-sm': '3px_3px_0px_0px_#121212',
        'hard-4': '4px_4px_0px_0px_#121212',
        'hard-6': '6px_6px_0px_0px_#121212',
        'hard-8': '8px_8px_0px_0px_#121212',
      },
      keyframes: {
        'fade-in-up': {
          '0%': { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        'fade-in-up': 'fade-in-up 0.5s ease-out forwards',
      },
    },
  },
  plugins: [],
};
