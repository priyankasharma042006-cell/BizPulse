import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from '@/lib/auth';
import { AuthScreen } from '@/screens/AuthScreen';
import { AppShell, type AppScreen } from '@/components/AppShell';
import { Dashboard } from '@/screens/Dashboard';
import { QuickLog } from '@/screens/QuickLog';
import { Inventory } from '@/screens/Inventory';
import { Insights } from '@/screens/Insights';
import { AIChat } from '@/screens/AIChat';
import { Circle, Square, Triangle } from 'lucide-react';

function AppContent() {
  const { user, business, loading } = useAuth();
  const [screen, setScreen] = useState<AppScreen>('dashboard');

  // Reset to dashboard when auth state changes
  useEffect(() => {
    if (user && business) setScreen('dashboard');
  }, [user?.uid, business?.id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="flex items-center gap-1.5">
            <Circle className="h-8 w-8 animate-pulse" fill="#D02020" stroke="#D02020" strokeWidth={1} />
            <Square className="h-8 w-8 animate-pulse" fill="#1040C0" stroke="#1040C0" strokeWidth={1} style={{ animationDelay: '150ms' }} />
            <Triangle className="h-8 w-8 animate-pulse" fill="#F0C020" stroke="#F0C020" strokeWidth={1} style={{ animationDelay: '300ms' }} />
          </div>
          <span className="font-black uppercase text-xl tracking-tighter">BizPulse</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  return (
    <AppShell current={screen} onNavigate={setScreen}>
      {screen === 'dashboard' && <Dashboard />}
      {screen === 'quick-log' && <QuickLog />}
      {screen === 'inventory' && <Inventory />}
      {screen === 'insights' && <Insights />}
      {screen === 'chat' && <AIChat />}
    </AppShell>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
