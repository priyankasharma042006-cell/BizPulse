import { useState, useRef, useEffect } from 'react';
import { Send, MessageCircle, Sparkles } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import type { Transaction, Item, Bill } from '@/lib/supabase';
import { buildDailyData, computeHealthScore, projectCashFlow } from '@/lib/analytics';

type ChatMessage = {
  role: 'user' | 'assistant';
  content: string;
};

export function AIChat() {
  const { business } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: 'Hi! I am your business co-pilot. Ask me anything about your sales, expenses, cash flow, or inventory.',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  async function sendMessage() {
    if (!input.trim() || !business || loading) return;
    const userMsg = input.trim();
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', content: userMsg }]);
    setLoading(true);

    try {
      // Gather business data to send as context
      const [txRes, itemRes, billRes] = await Promise.all([
        supabase.from('transactions').select('*').eq('business_id', business.id).order('date', { ascending: true }),
        supabase.from('items').select('*').eq('business_id', business.id),
        supabase.from('bills').select('*').eq('business_id', business.id),
      ]);

      const transactions = txRes.data as Transaction[] ?? [];
      const items = itemRes.data as Item[] ?? [];
      const bills = billRes.data as Bill[] ?? [];

      const daily = buildDailyData(transactions);
      const health = computeHealthScore(business.opening_balance, daily, items, bills);
      const { runwayDays, riskDate } = projectCashFlow(business.opening_balance, daily, bills, 30);

      const totalSales = transactions.filter((t) => t.type === 'sale').reduce((a, t) => a + t.amount, 0);
      const totalExpenses = transactions.filter((t) => t.type === 'expense').reduce((a, t) => a + t.amount, 0);
      const currentBalance = business.opening_balance + totalSales - totalExpenses;

      // Build aggregated context (no personal/customer data)
      const context = {
        business: { name: business.name, type: business.type, opening_balance: business.opening_balance },
        summary: {
          current_balance: Math.round(currentBalance),
          total_sales: Math.round(totalSales),
          total_expenses: Math.round(totalExpenses),
          transaction_count: transactions.length,
          item_count: items.length,
          health_score: health.score,
          health_reasons: health.reasons,
          runway_days: runwayDays,
          risk_date: riskDate,
        },
        last_7_days: daily.slice(-7).map((d) => ({ date: d.date, sales: Math.round(d.sales), expenses: Math.round(d.expenses) })),
        low_stock_items: items.filter((i) => i.stock <= i.reorder_level && i.reorder_level > 0).map((i) => ({
          name: i.name, stock: i.stock, unit: i.unit, reorder_level: i.reorder_level,
        })),
        pending_bills: bills.filter((b) => b.status === 'pending').map((b) => ({
          payee: b.payee, amount: b.amount, due_date: b.due_date,
        })),
      };

      // Call the edge function
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-chat`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({ question: userMsg, context }),
        }
      );

      if (!response.ok) {
        throw new Error(`Request failed (${response.status})`);
      }

      const data = await response.json();
      if (!data.answer) {
        throw new Error('Invalid response from AI');
      }

      setMessages((prev) => [...prev, { role: 'assistant', content: data.answer }]);
    } catch {
      // Fallback: rule-based answer
      const fallback = generateFallbackAnswer(userMsg, {
        totalSales: transactions?.length ?? 0,
      });
      setMessages((prev) => [...prev, {
        role: 'assistant',
        content: fallback,
      }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-2xl mx-auto px-4 md:px-8 py-6 flex flex-col" style={{ minHeight: 'calc(100vh - 64px)' }}>
      <div className="flex items-center gap-2 mb-4">
        <div className="h-10 w-10 rounded-full bg-primary-blue border-2 border-black flex items-center justify-center shadow-hard-4">
          <Sparkles className="h-5 w-5 text-white" strokeWidth={2.5} />
        </div>
        <div>
          <h1 className="font-black uppercase text-xl tracking-tighter">Ask Your Business</h1>
          <p className="text-xs font-medium text-gray-500">AI-powered answers from your data</p>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto pb-4 mb-4">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] border-2 border-black p-3 md:p-4 ${
                msg.role === 'user'
                  ? 'bg-primary-red text-white shadow-hard-4'
                  : 'bg-white shadow-hard-4'
              }`}
            >
              <p className="text-sm font-medium leading-relaxed">{msg.content}</p>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white border-2 border-black p-4 shadow-hard-4">
              <div className="flex gap-1">
                <div className="h-2 w-2 rounded-full bg-primary-red animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="h-2 w-2 rounded-full bg-primary-yellow animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="h-2 w-2 rounded-full bg-primary-blue animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Ask about your business..."
          className="flex-1 border-2 border-black p-3 focus:outline-none focus:shadow-hard-4 transition-all text-sm"
        />
        <button
          onClick={sendMessage}
          disabled={loading || !input.trim()}
          className="bg-primary-blue text-white border-2 border-black p-3 shadow-hard-4 active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all disabled:opacity-50"
        >
          <Send className="h-5 w-5" strokeWidth={2.5} />
        </button>
      </div>

      {/* Suggested questions */}
      {messages.length <= 1 && (
        <div className="mt-4 flex flex-wrap gap-2">
          {[
            'How is my cash flow?',
            'What should I reorder?',
            'What is my health score?',
            'What are my biggest expenses?',
          ].map((q) => (
            <button
              key={q}
              onClick={() => setInput(q)}
              className="border-2 border-black bg-white px-3 py-2 text-xs font-bold uppercase tracking-wider hover:bg-primary-yellow transition-all"
            >
              {q}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function generateFallbackAnswer(question: string, _data: { totalSales: number }): string {
  const lower = question.toLowerCase();
  if (lower.includes('cash') || lower.includes('balance') || lower.includes('flow')) {
    return 'I cannot connect to the AI service right now. Please check your internet connection and try again. You can still see your cash balance and projections on the Dashboard.';
  }
  if (lower.includes('reorder') || lower.includes('stock') || lower.includes('inventory')) {
    return 'I cannot connect to the AI service right now. Check the Inventory tab for low-stock items and reorder suggestions.';
  }
  if (lower.includes('health') || lower.includes('score')) {
    return 'I cannot connect to the AI service right now. Your health score is visible on the Dashboard with a full breakdown.';
  }
  return 'I cannot connect to the AI service right now. Please try again later. All your data is still available on the Dashboard and Inventory tabs.';
}
