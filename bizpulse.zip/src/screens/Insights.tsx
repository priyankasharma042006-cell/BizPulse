import { useEffect, useState } from 'react';
import { Sparkles, ArrowRight, TrendingUp, AlertTriangle, Package } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import type { Transaction, Item, Bill } from '@/lib/supabase';
import {
  buildDailyData,
  computeHealthScore,
  projectCashFlow,
  generateAlerts,
} from '@/lib/analytics';

export function Insights() {
  const { business } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const [loading, setLoading] = useState(true);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    if (!business) return;
    Promise.all([
      supabase.from('transactions').select('*').eq('business_id', business.id).order('date', { ascending: true }),
      supabase.from('items').select('*').eq('business_id', business.id),
      supabase.from('bills').select('*').eq('business_id', business.id),
    ]).then(([txRes, itemRes, billRes]) => {
      setTransactions(txRes.data as Transaction[] ?? []);
      setItems(itemRes.data as Item[] ?? []);
      setBills(billRes.data as Bill[] ?? []);
      setLoading(false);
    });
  }, [business]);

  const daily = buildDailyData(transactions);
  const health = computeHealthScore(business?.opening_balance ?? 0, daily, items, bills);
  const { runwayDays, riskDate } = projectCashFlow(business?.opening_balance ?? 0, daily, bills, 30);
  const alerts = generateAlerts(business?.opening_balance ?? 0, daily, items, bills);

  // Top 3 actions
  const topActions = alerts.slice(0, 3);

  // Sales trend
  const last7Sales = daily.slice(-7).reduce((a, d) => a + d.sales, 0);
  const prev7Sales = daily.slice(-14, -7).reduce((a, d) => a + d.sales, 0);
  const salesChange = prev7Sales > 0 ? ((last7Sales - prev7Sales) / prev7Sales) * 100 : 0;

  async function fetchAISummary() {
    if (!business) return;
    setAiLoading(true);
    try {
      const totalSales = transactions.filter((t) => t.type === 'sale').reduce((a, t) => a + t.amount, 0);
      const totalExpenses = transactions.filter((t) => t.type === 'expense').reduce((a, t) => a + t.amount, 0);
      const context = {
        business: { name: business.name, type: business.type },
        summary: {
          current_balance: Math.round(business.opening_balance + totalSales - totalExpenses),
          total_sales: Math.round(totalSales),
          total_expenses: Math.round(totalExpenses),
          health_score: health.score,
          runway_days: runwayDays,
          risk_date: riskDate,
          sales_change_pct: Math.round(salesChange),
        },
        last_7_days: daily.slice(-7).map((d) => ({ sales: Math.round(d.sales), expenses: Math.round(d.expenses) })),
        top_alerts: alerts.slice(0, 3),
      };

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-chat`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            question: 'Give me a weekly insight digest: summarize what changed, how the business is doing, and the top 3 actions to take next week. Keep it concise and plain-language.',
            context,
          }),
        }
      );

      if (response.ok) {
        const data = await response.json();
        if (data.answer) setAiSummary(data.answer);
      }
    } catch {
      // Silent fallback
    } finally {
      setAiLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[40vh]">
        <div className="h-12 w-12 rounded-full border-4 border-black border-t-primary-red animate-spin" />
      </div>
    );
  }

  if (transactions.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-12 text-center">
        <h1 className="font-black uppercase text-2xl md:text-4xl tracking-tighter mb-4">Weekly Digest</h1>
        <p className="text-sm font-medium text-gray-600">Log some sales and expenses first, then come back for insights.</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 md:px-8 py-6 space-y-6">
      {/* Poster headline */}
      <div className="border-b-4 border-black pb-6">
        <span className="font-bold uppercase text-xs tracking-widest text-primary-red mb-3 block">
          Weekly Digest
        </span>
        <h1 className="font-black uppercase text-3xl sm:text-4xl lg:text-6xl tracking-tighter leading-[0.9]">
          {salesChange >= 0 ? 'Sales Are Up' : 'Sales Are Down'}<br />
          {Math.abs(Math.round(salesChange))}% This Week
        </h1>
      </div>

      {/* AI Summary */}
      <div className="bg-primary-blue text-white border-2 md:border-4 border-black shadow-hard-4 p-5 md:p-6">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="h-5 w-5" strokeWidth={2.5} />
          <h2 className="font-bold uppercase text-sm tracking-widest">AI Summary</h2>
        </div>
        {aiSummary ? (
          <p className="text-sm md:text-base font-medium leading-relaxed">{aiSummary}</p>
        ) : aiLoading ? (
          <div className="flex gap-1">
            <div className="h-2 w-2 rounded-full bg-white animate-bounce" style={{ animationDelay: '0ms' }} />
            <div className="h-2 w-2 rounded-full bg-primary-yellow animate-bounce" style={{ animationDelay: '150ms' }} />
            <div className="h-2 w-2 rounded-full bg-white animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        ) : (
          <div>
            <p className="text-sm font-medium mb-4 opacity-90">
              Get a plain-language summary of your week from AI.
            </p>
            <button
              onClick={fetchAISummary}
              className="bg-primary-yellow text-black border-2 border-black px-4 py-2 font-bold uppercase text-xs tracking-wider shadow-hard-4 active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all"
            >
              Generate Summary
            </button>
          </div>
        )}
      </div>

      {/* Top 3 action cards */}
      <section>
        <h2 className="font-bold uppercase text-sm tracking-widest mb-4">Top 3 Actions This Week</h2>
        {topActions.length > 0 ? (
          <div className="space-y-3">
            {topActions.map((action, i) => {
              const isCritical = action.severity === 'critical';
              const Icon = isCritical ? AlertTriangle : action.kind.includes('stock') ? Package : TrendingUp;
              return (
                <div
                  key={i}
                  className={`flex items-start gap-4 border-2 md:border-4 border-black shadow-hard-4 p-4 md:p-5 ${
                    isCritical ? 'bg-primary-red text-white' : action.severity === 'warning' ? 'bg-primary-yellow' : 'bg-white'
                  }`}
                >
                  <div className={`h-10 w-10 flex-shrink-0 border-2 border-black flex items-center justify-center ${
                    isCritical ? 'bg-white' : 'bg-primary-blue'
                  }`}>
                    <Icon className={`h-5 w-5 ${isCritical ? 'text-primary-red' : 'text-white'}`} strokeWidth={2.5} />
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-sm mb-1">{action.reason}</p>
                    <p className={`text-xs font-medium ${isCritical ? 'text-white/80' : 'text-gray-600'}`}>
                      → {action.suggested_action}
                    </p>
                  </div>
                  <ArrowRight className={`h-5 w-5 flex-shrink-0 ${isCritical ? 'text-white' : 'text-black'}`} />
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white border-2 md:border-4 border-black shadow-hard-4 p-5 text-center">
            <p className="text-sm font-medium text-gray-600">No urgent actions. Your business looks healthy!</p>
          </div>
        )}
      </section>

      {/* Week stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white border-2 md:border-4 border-black shadow-hard-4 p-4 md:p-5">
          <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2">Sales This Week</div>
          <div className="font-black text-2xl tracking-tighter">₹{Math.round(last7Sales).toLocaleString('en-IN')}</div>
          <div className={`text-xs font-bold mt-1 ${salesChange >= 0 ? 'text-primary-blue' : 'text-primary-red'}`}>
            {salesChange >= 0 ? '↑' : '↓'} {Math.abs(Math.round(salesChange))}% vs last week
          </div>
        </div>
        <div className="bg-white border-2 md:border-4 border-black shadow-hard-4 p-4 md:p-5">
          <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2">Health Score</div>
          <div className="font-black text-2xl tracking-tighter" style={{
            color: health.score >= 70 ? '#1040C0' : health.score >= 40 ? '#F0C020' : '#D02020',
          }}>
            {health.score}/100
          </div>
          <div className="text-xs font-medium text-gray-500 mt-1">{health.reasons.length} factors</div>
        </div>
      </div>
    </div>
  );
}
