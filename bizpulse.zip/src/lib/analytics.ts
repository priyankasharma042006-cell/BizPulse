import type { Transaction, Item, Bill } from './supabase';

export type DailyData = {
  date: string;
  sales: number;
  expenses: number;
};

export type CashProjection = {
  date: string;
  projectedBalance: number;
  probabilityNegative: number;
};

export type HealthScore = {
  score: number;
  reasons: { label: string; points: number }[];
};

export type ForecastResult = {
  forecast: number[];
  confidence: 'low' | 'medium' | 'high';
  labels: string[];
};

export type AlertSuggestion = {
  kind: string;
  severity: 'critical' | 'warning' | 'info';
  reason: string;
  suggested_action: string;
};

/**
 * Groups transactions into daily sales/expense totals.
 */
export function buildDailyData(transactions: Transaction[]): DailyData[] {
  const map = new Map<string, DailyData>();
  for (const t of transactions) {
    const existing = map.get(t.date) ?? { date: t.date, sales: 0, expenses: 0 };
    if (t.type === 'sale') existing.sales += t.amount;
    else existing.expenses += t.amount;
    map.set(t.date, existing);
  }
  return Array.from(map.values()).sort((a, b) => a.date.localeCompare(b.date));
}

/**
 * Simple moving average forecast with day-of-week seasonality.
 * Falls back to averages with <14 days of data.
 */
export function forecastDemand(daily: DailyData[], daysAhead = 7): ForecastResult {
  if (daily.length === 0) {
    return { forecast: [], confidence: 'low', labels: [] };
  }

  const sales = daily.map((d) => d.sales);
  const labels: string[] = [];
  const forecast: number[] = [];

  if (daily.length < 14) {
    const avg = sales.reduce((a, b) => a + b, 0) / sales.length;
    for (let i = 0; i < daysAhead; i++) {
      const d = new Date();
      d.setDate(d.getDate() + i + 1);
      labels.push(d.toLocaleDateString('en', { weekday: 'short' }));
      forecast.push(Math.round(avg));
    }
    return { forecast, confidence: 'low', labels };
  }

  // Day-of-week averages from the last 8 weeks
  const dowAvgs: number[][] = [[], [], [], [], [], [], []];
  for (const d of daily) {
    const dow = new Date(d.date).getDay();
    dowAvgs[dow].push(d.sales);
  }
  const dowMeans = dowAvgs.map((arr) =>
    arr.length > 0 ? arr.reduce((a, b) => a + b, 0) / arr.length : 0
  );

  // Recent trend (last 7 days vs previous 7 days)
  const recent7 = sales.slice(-7).reduce((a, b) => a + b, 0) / Math.min(7, sales.length);
  const prev7 = sales.slice(-14, -7).reduce((a, b) => a + b, 0) / Math.min(7, sales.length);
  const trendMultiplier = prev7 > 0 ? recent7 / prev7 : 1;

  for (let i = 0; i < daysAhead; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i + 1);
    const dow = d.getDay();
    labels.push(d.toLocaleDateString('en', { weekday: 'short' }));
    const projected = dowMeans[dow] * trendMultiplier;
    forecast.push(Math.max(0, Math.round(projected)));
  }

  const confidence = daily.length >= 56 ? 'high' : 'medium';
  return { forecast, confidence, labels };
}

/**
 * Monte Carlo cash-flow projection (1000 runs).
 * Returns daily projected balances and probability of going negative.
 */
export function projectCashFlow(
  openingBalance: number,
  daily: DailyData[],
  bills: Bill[],
  daysAhead = 30
): { projections: CashProjection[]; runwayDays: number | null; riskDate: string | null } {
  if (daily.length === 0) {
    return { projections: [], runwayDays: null, riskDate: null };
  }

  const sales = daily.map((d) => d.sales);
  const expenses = daily.map((d) => d.expenses);

  const avgSales = sales.reduce((a, b) => a + b, 0) / sales.length;
  const avgExpenses = expenses.reduce((a, b) => a + b, 0) / expenses.length;

  // Standard deviations for variability
  const salesStd = Math.sqrt(
    sales.reduce((sq, v) => sq + (v - avgSales) ** 2, 0) / sales.length
  ) || 1;
  const expenseStd = Math.sqrt(
    expenses.reduce((sq, v) => sq + (v - avgExpenses) ** 2, 0) / expenses.length
  ) || 1;

  // Build bill schedule
  const billMap = new Map<string, number>();
  const today = new Date();
  for (const bill of bills) {
    if (bill.status === 'paid') continue;
    const due = new Date(bill.due_date);
    const diffDays = Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays >= 0 && diffDays < daysAhead) {
      const key = String(diffDays);
      billMap.set(key, (billMap.get(key) ?? 0) + bill.amount);
    }
  }

  const runs = 1000;
  const projections: CashProjection[] = [];
  let runwayDays: number | null = null;
  let riskDate: string | null = null;

  for (let day = 1; day <= daysAhead; day++) {
    let negativeCount = 0;
    const balances: number[] = [];

    for (let run = 0; run < runs; run++) {
      let balance = day === 1 ? openingBalance : projections[day - 2].projectedBalance;

      // Random sample using normal approximation (Box-Muller)
      const u1 = Math.random() || 0.0001;
      const u2 = Math.random();
      const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
      const daySales = Math.max(0, avgSales + z * salesStd);
      const dayExpenses = avgExpenses + (z > 0 ? z * expenseStd * 0.5 : 0);
      const billAmount = billMap.get(String(day - 1)) ?? 0;

      balance += daySales - dayExpenses - billAmount;
      balances.push(balance);
      if (balance < 0) negativeCount++;
    }

    const avgBalance = balances.reduce((a, b) => a + b, 0) / balances.length;
    const prob = negativeCount / runs;
    const d = new Date();
    d.setDate(d.getDate() + day);
    const dateStr = d.toISOString().split('T')[0];

    projections.push({
      date: dateStr,
      projectedBalance: Math.round(avgBalance),
      probabilityNegative: prob,
    });

    if (runwayDays === null && avgBalance < 0) {
      runwayDays = day;
      riskDate = dateStr;
    }
  }

  return { projections, runwayDays, riskDate };
}

/**
 * Business health score (0-100) with explainable deductions.
 */
export function computeHealthScore(
  openingBalance: number,
  daily: DailyData[],
  items: Item[],
  bills: Bill[]
): HealthScore {
  const reasons: { label: string; points: number }[] = [];
  let score = 100;

  // Liquidity (30%)
  const recentExpenses = daily.slice(-7).reduce((a, d) => a + d.expenses, 0) / 7;
  const liquidityRatio = recentExpenses > 0 ? openingBalance / recentExpenses : 999;
  if (liquidityRatio < 7) {
    const deduction = Math.round((1 - liquidityRatio / 7) * 30);
    score -= deduction;
    reasons.push({ label: 'Low cash runway', points: deduction });
  }

  // Margin trend (25%)
  const recentSales = daily.slice(-7).reduce((a, d) => a + d.sales, 0);
  const recentExps = daily.slice(-7).reduce((a, d) => a + d.expenses, 0);
  const margin = recentSales > 0 ? (recentSales - recentExps) / recentSales : 0;
  if (margin < 0.1) {
    const deduction = Math.round((0.1 - Math.max(margin, 0)) / 0.1 * 25);
    score -= deduction;
    reasons.push({ label: 'Thin profit margin', points: deduction });
  }

  // Stock health (15%)
  const lowStockItems = items.filter((i) => i.stock <= i.reorder_level && i.reorder_level > 0);
  if (items.length > 0 && lowStockItems.length > 0) {
    const deduction = Math.round((lowStockItems.length / items.length) * 15);
    score -= deduction;
    reasons.push({ label: `${lowStockItems.length} items need reorder`, points: deduction });
  }

  // Bills overdue (20%)
  const today = new Date().toISOString().split('T')[0];
  const overdueBills = bills.filter((b) => b.status === 'pending' && b.due_date < today);
  if (overdueBills.length > 0) {
    const deduction = Math.min(20, overdueBills.length * 5);
    score -= deduction;
    reasons.push({ label: `${overdueBills.length} overdue bills`, points: deduction });
  }

  // Consistency (10%) — days with sales in last 14
  const activeDays = daily.filter((d) => d.sales > 0).slice(-14).length;
  if (activeDays < 10) {
    const deduction = Math.round((1 - activeDays / 10) * 10);
    score -= deduction;
    reasons.push({ label: 'Irregular logging', points: deduction });
  }

  return { score: Math.max(0, Math.min(100, score)), reasons };
}

/**
 * Generate alert suggestions from the data.
 */
export function generateAlerts(
  openingBalance: number,
  daily: DailyData[],
  items: Item[],
  bills: Bill[]
): AlertSuggestion[] {
  const alerts: AlertSuggestion[] = [];

  // Cash risk
  const { runwayDays, riskDate } = projectCashFlow(openingBalance, daily, bills, 30);
  if (runwayDays !== null && runwayDays <= 30) {
    alerts.push({
      kind: 'cash_risk',
      severity: runwayDays <= 14 ? 'critical' : 'warning',
      reason: `Your balance may go negative in ${runwayDays} days (around ${riskDate}).`,
      suggested_action:
        runwayDays <= 14
          ? 'Collect receivables, delay non-essential expenses, or arrange short-term credit now.'
          : 'Review upcoming bills and consider collecting receivables early.',
    });
  }

  // Low stock
  const lowStock = items.filter((i) => i.stock <= i.reorder_level && i.reorder_level > 0);
  for (const item of lowStock.slice(0, 3)) {
    alerts.push({
      kind: 'low_stock',
      severity: 'warning',
      reason: `${item.name} is at or below reorder level (${item.stock} ${item.unit} left).`,
      suggested_action: `Order more ${item.name} before you run out.`,
    });
  }

  // Overdue bills
  const today = new Date().toISOString().split('T')[0];
  const overdue = bills.filter((b) => b.status === 'pending' && b.due_date < today);
  for (const bill of overdue.slice(0, 2)) {
    alerts.push({
      kind: 'overdue_bill',
      severity: 'critical',
      reason: `${bill.payee} bill of ${bill.amount} was due on ${bill.due_date} and is overdue.`,
      suggested_action: `Pay ${bill.payee} or negotiate a new due date.`,
    });
  }

  // Anomaly: unusual drop in sales
  if (daily.length >= 7) {
    const last7 = daily.slice(-7);
    const prev7 = daily.slice(-14, -7);
    if (prev7.length === 7) {
      const lastAvg = last7.reduce((a, d) => a + d.sales, 0) / 7;
      const prevAvg = prev7.reduce((a, d) => a + d.sales, 0) / 7;
      if (prevAvg > 0 && lastAvg < prevAvg * 0.6) {
        alerts.push({
          kind: 'sales_drop',
          severity: 'warning',
          reason: `Sales dropped ${Math.round((1 - lastAvg / prevAvg) * 100)}% compared to last week.`,
          suggested_action: 'Check for external factors or entry errors. Consider a promotion.',
        });
      }
    }
  }

  return alerts;
}

/**
 * Smart reorder suggestion using safety stock formula.
 */
export function suggestReorder(
  item: Item,
  daily: DailyData[],
  leadTimeDays = 3
): { shouldReorder: boolean; quantity: number; reason: string } {
  if (item.reorder_level <= 0) {
    return { shouldReorder: false, quantity: 0, reason: 'No reorder level set.' };
  }

  // Estimate daily demand for this item (rough: total sales / items count)
  const avgDailySales = daily.length > 0
    ? daily.slice(-14).reduce((a, d) => a + d.sales, 0) / Math.min(14, daily.length)
    : 0;

  const demandOverLeadTime = avgDailySales * leadTimeDays;
  const safetyStock = avgDailySales * 1.5; // ~1.65 sigma simplified
  const reorderQty = Math.max(0, Math.round(demandOverLeadTime + safetyStock - item.stock));

  return {
    shouldReorder: item.stock <= item.reorder_level,
    quantity: reorderQty,
    reason: reorderQty > 0
      ? `Order ${reorderQty} ${item.unit} to cover ${leadTimeDays} days + safety stock.`
      : 'Stock is adequate for now.',
  };
}
