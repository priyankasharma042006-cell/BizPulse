import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  type User,
} from 'firebase/auth';
import { firebaseAuth } from './firebase';
import { supabase } from './supabase';
import type { Business } from './supabase';

interface AuthContextValue {
  user: User | null;
  business: Business | null;
  loading: boolean;
  signUp: (email: string, password: string) => Promise<{ user: User | null; error: string | null }>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshBusiness: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

function friendlyError(err: unknown): string {
  const code = (err as { code?: string })?.code ?? '';
  switch (code) {
    case 'auth/email-already-in-use':
      return 'An account with this email already exists.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/weak-password':
      return 'Password should be at least 6 characters.';
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'Incorrect email or password.';
    case 'auth/too-many-requests':
      return 'Too many attempts. Please try again later.';
    case 'auth/network-request-failed':
      return 'Network error. Check your connection and try again.';
    default:
      return 'Something went wrong. Please try again.';
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [business, setBusiness] = useState<Business | null>(null);
  const [loading, setLoading] = useState(true);

  async function loadBusiness(userId: string) {
    const { data } = await supabase
      .from('businesses')
      .select('*')
      .eq('owner_id', userId)
      .maybeSingle();
    setBusiness(data as Business | null);
  }

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(firebaseAuth, (fbUser) => {
      setUser(fbUser);
      if (fbUser) {
        loadBusiness(fbUser.uid).finally(() => setLoading(false));
      } else {
        setBusiness(null);
        setLoading(false);
      }
    });
    return unsubscribe;
  }, []);

  const signUp = async (email: string, password: string) => {
    try {
      const cred = await createUserWithEmailAndPassword(firebaseAuth, email, password);
      return { user: cred.user, error: null };
    } catch (err) {
      return { user: null, error: friendlyError(err) };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      await signInWithEmailAndPassword(firebaseAuth, email, password);
      return { error: null };
    } catch (err) {
      return { error: friendlyError(err) };
    }
  };

  const signOut = async () => {
    await firebaseSignOut(firebaseAuth);
    setBusiness(null);
  };

  const refreshBusiness = async () => {
    const current = firebaseAuth.currentUser;
    if (current) await loadBusiness(current.uid);
  };

  return (
    <AuthContext.Provider
      value={{ user, business, loading, signUp, signIn, signOut, refreshBusiness }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
